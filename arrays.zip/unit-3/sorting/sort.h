#ifndef SORT_H
#define SORT_H

void quicksort(int a[], int size);
void mergesort(int a[], int size);
void heapsort(int a[], int size);

#endif
